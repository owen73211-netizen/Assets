@echo off
start "LiteLLM" cmd /k "cd /d C:\Users\owenl\litellm && .venv\Scripts\activate && litellm --config litellm_config.yaml --port 4000"
timeout /t 3 /nobreak >nul
start "Careerlink" cmd /k "cd /d C:\PATH\TO\careerlink\careerlink\backend && python -m uvicorn main:app --host 0.0.0.0 --port 8000"
timeout /t 2 /nobreak >nul
start http://localhost:8000
