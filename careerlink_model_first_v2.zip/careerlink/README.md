# Careerlink AI — Model-First Edition

## What changed
- Removed team selection/routing from the active UI. Careerlink now uses exactly one selected LiteLLM model per request.
- The model selector is attached directly to the send arrow area and also appears in the right-side Models panel.
- The right panel lists models returned live by LiteLLM `/v1/models`.
- Provider/API status is shown without exposing secret API keys. Keys remain in LiteLLM.
- Added a live Grok-style activity feed: command started, model connection booted, response received, files created, errors.
- Removed the old "Welcome to Careerlink AI..." welcome message from the UI and filters it from persisted chat history when chats are loaded.
- Document title is exactly `Owen's Management`.
- Favicon uses `careerlink-v2.png` from the Assets GitHub repository.
- Existing file upload/download and code-file extraction remain available.
- Projects/chats remain, but teams are intentionally paused so the model-first system is stable before teams/custom roles are added back.

## Start LiteLLM
Open Command Prompt:

```bat
cd C:\Users\owenl\litellm
.venv\Scripts\activate
litellm --config litellm_config.yaml --port 4000
```

Leave that window open.

Your LiteLLM config must expose every model you want to use through a `model_name`. Gemini will automatically appear in Careerlink if the Gemini model is correctly configured in LiteLLM and its API key is available to LiteLLM.

## Start Careerlink
Open a second Command Prompt:

```bat
cd C:\path\to\careerlink\careerlink\backend
python -m pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

Then open:

http://localhost:8000

## Optional one-click startup
Create a file such as `start-careerlink.bat` next to the `careerlink` folder:

```bat
@echo off
start "LiteLLM" cmd /k "cd /d C:\Users\owenl\litellm && .venv\Scripts\activate && litellm --config litellm_config.yaml --port 4000"
timeout /t 3 /nobreak >nul
start "Careerlink" cmd /k "cd /d C:\path\to\careerlink\careerlink\backend && python -m uvicorn main:app --host 0.0.0.0 --port 8000"
start http://localhost:8000
```

Replace only the Careerlink path with the actual folder location.

## Gemini
You do NOT put the Gemini key into the Careerlink frontend. Put it in your LiteLLM configuration/environment the same way you have already been configuring your other providers. Restart LiteLLM after changing the key/config.

If `/v1/models` from LiteLLM includes the Gemini model, it will appear in the Careerlink model selector automatically. Click it in the right-side panel or the selector beside the send arrow.

## Important
Careerlink never displays the actual API key. The "API / Providers" section only reports provider connectivity inferred from the models LiteLLM exposes.

Teams/custom roles are deliberately not active in this edition. This avoids the broken team-builder state from interfering with model selection. They can be layered back onto the model system later.


## Gemini setup
Careerlink gets Gemini through LiteLLM. Add a Gemini model to `C:\Users\owenl\litellm\litellm_config.yaml`:

```yaml
  - model_name: gemini-2.5-flash
    litellm_params:
      model: gemini/gemini-2.5-flash
      api_key: os.environ/GEMINI_API_KEY
```

In the same CMD window used to start LiteLLM, set the key for that session before starting LiteLLM:

```bat
set GEMINI_API_KEY=YOUR_GEMINI_API_KEY
litellm --config litellm_config.yaml --port 4000
```

Do not put the actual key into Careerlink source files. After restarting LiteLLM, click `↻ Models` in Careerlink. `gemini-2.5-flash` should appear in the right-side Models panel.
