"""Single-model LiteLLM client used by the model-first Careerlink UI."""
import httpx
from config import LITELLM_BASE_URL, LITELLM_TIMEOUT, SYSTEM_PROMPT

class LLMError(Exception):
    pass

async def list_models():
    url=f"{LITELLM_BASE_URL.rstrip('/')}/v1/models"
    async with httpx.AsyncClient(timeout=10) as client:
        r=await client.get(url)
        r.raise_for_status()
        data=r.json()
    return [x.get("id") for x in data.get("data",[]) if x.get("id")]

async def call_model(model: str, user_message: str, history=None):
    if not model:
        raise LLMError("No model selected.")
    messages=[{"role":"system","content":SYSTEM_PROMPT}]
    if history:
        for m in history[-30:]:
            if m.get("role") in ("user","assistant","system") and m.get("content"):
                messages.append({"role":m["role"],"content":m["content"]})
    messages.append({"role":"user","content":user_message})
    url=f"{LITELLM_BASE_URL.rstrip('/')}/v1/chat/completions"
    payload={"model":model,"messages":messages,"temperature":0.5,"max_tokens":8192}
    async with httpx.AsyncClient(timeout=LITELLM_TIMEOUT) as client:
        try:
            r=await client.post(url,json=payload)
        except httpx.ConnectError:
            raise LLMError(f"Cannot reach LiteLLM at {LITELLM_BASE_URL}. Start LiteLLM first.")
        except httpx.TimeoutException:
            raise LLMError(f"Timed out waiting for {model}.")
    if r.status_code != 200:
        raise LLMError(f"{model} returned HTTP {r.status_code}: {r.text[:500]}")
    try:
        content=r.json()["choices"][0]["message"]["content"]
    except (KeyError,IndexError,TypeError,ValueError):
        raise LLMError("LiteLLM returned an unexpected response.")
    return {"model_used":model,"content":content}

async def check_litellm():
    try:
        models=await list_models()
        return {"ok":True,"models":models}
    except Exception as e:
        return {"ok":False,"error":str(e),"models":[]}
