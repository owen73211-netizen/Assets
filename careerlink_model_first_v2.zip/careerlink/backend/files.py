"""
File upload, storage, and download helpers.
"""

import uuid
import zipfile
import tarfile
import io
import mimetypes
from pathlib import Path
from datetime import datetime
from config import UPLOADS_DIR, OUTPUTS_DIR


def save_upload(filename: str, content: bytes) -> dict:
    """Save an uploaded file and return metadata."""
    safe_name = Path(filename).name
    file_id = str(uuid.uuid4())[:8]
    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    stored_name = f"{stamp}_{file_id}_{safe_name}"
    path = UPLOADS_DIR / stored_name
    path.write_bytes(content)

    return {
        "id": file_id,
        "original_name": safe_name,
        "stored_name": stored_name,
        "path": str(path),
        "size": len(content),
        "mime": mimetypes.guess_type(safe_name)[0] or "application/octet-stream",
    }


def read_upload(stored_name: str, max_chars: int = 30000) -> str:
    """Read a previously uploaded text file (or binary note)."""
    path = UPLOADS_DIR / stored_name
    if not path.exists():
        raise FileNotFoundError(f"Upload not found: {stored_name}")

    # Try text first
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        if len(text) > max_chars:
            return text[:max_chars] + f"\n\n...[truncated, {len(text)} total chars]"
        return text
    except Exception:
        return f"[Binary file: {path.name}, {path.stat().st_size} bytes]"


def write_output_file(filename: str, content: str | bytes) -> dict:
    """Write a file the agents produced so the user can download it."""
    safe_name = Path(filename).name
    file_id = str(uuid.uuid4())[:8]
    stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    stored_name = f"{stamp}_{file_id}_{safe_name}"
    path = OUTPUTS_DIR / stored_name

    if isinstance(content, str):
        path.write_text(content, encoding="utf-8")
        size = path.stat().st_size
    else:
        path.write_bytes(content)
        size = len(content)

    return {
        "id": file_id,
        "filename": safe_name,
        "stored_name": stored_name,
        "download_url": f"/api/files/download/{stored_name}",
        "size": size,
    }


def make_zip(files: list[tuple[str, str | bytes]], zip_name: str = "careerlink_output.zip") -> dict:
    """
    Create a zip from a list of (filename, content) pairs.
    Returns metadata including download_url.
    """
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, content in files:
            if isinstance(content, str):
                zf.writestr(name, content.encode("utf-8"))
            else:
                zf.writestr(name, content)

    data = buf.getvalue()
    return write_output_file(zip_name, data)


def make_tar_gz(files: list[tuple[str, str | bytes]], tar_name: str = "careerlink_output.tar.gz") -> dict:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for name, content in files:
            raw = content.encode("utf-8") if isinstance(content, str) else content
            info = tarfile.TarInfo(name=name)
            info.size = len(raw)
            tar.addfile(info, io.BytesIO(raw))
    return write_output_file(tar_name, buf.getvalue())


def list_outputs(limit: int = 30) -> list[dict]:
    files = sorted(OUTPUTS_DIR.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)
    result = []
    for p in files[:limit]:
        result.append({
            "filename": p.name,
            "size": p.stat().st_size,
            "download_url": f"/api/files/download/{p.name}",
            "modified": datetime.utcfromtimestamp(p.stat().st_mtime).isoformat() + "Z",
        })
    return result


def delete_output(stored_name: str) -> bool:
    """Delete a generated/output file by stored name. Returns True if deleted."""
    if ".." in stored_name or "/" in stored_name or "\\" in stored_name:
        return False
    path = OUTPUTS_DIR / stored_name
    if path.exists() and path.is_file():
        path.unlink()
        return True
    path = UPLOADS_DIR / stored_name
    if path.exists() and path.is_file():
        path.unlink()
        return True
    return False
