"""
Careerlink AI — model-first FastAPI backend.
Runs on http://localhost:8000 and talks to LiteLLM on http://localhost:4000.
"""
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pathlib import Path
import re, traceback

from config import OUTPUTS_DIR, UPLOADS_DIR, DEFAULT_PROJECT
from llm import call_model, check_litellm, list_models, LLMError
from files import save_upload, write_output_file, make_zip, list_outputs, delete_output
from store import list_projects, create_project, delete_project, list_chats, get_chat, save_chat, delete_chat

app=FastAPI(title="Careerlink AI",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

class ChatRequest(BaseModel):
    message:str
    history:list[dict]=[]
    project_id:str="careerlink-platform"
    model:str

class ChatResponse(BaseModel):
    reply:dict
    files:list[dict]=[]

CODE_BLOCK_RE=re.compile(r"```(?:(\w+)\n)?(.*?)```",re.DOTALL)

def extract_code_files(text:str):
    files=[]
    for i,m in enumerate(CODE_BLOCK_RE.finditer(text or "")):
        lang=(m.group(1) or "").lower()
        code=m.group(2).strip()
        if not code: continue
        first=code.split("\n",1)[0]
        name=None
        for pat in (r"^//\s*([\w./-]+\.\w+)",r"^#\s*([\w./-]+\.\w+)",r"^<!--\s*([\w./-]+\.\w+)\s*-->"):
            x=re.match(pat,first)
            if x:
                name=x.group(1); code=code.split("\n",1)[1] if "\n" in code else code; break
        if not name:
            ext={"python":"py","py":"py","javascript":"js","js":"js","typescript":"ts","ts":"ts",
                 "html":"html","css":"css","json":"json","yaml":"yaml","yml":"yml","bash":"sh","sh":"sh"}.get(lang,"txt")
            name=f"file_{i+1}.{ext}"
        files.append((name,code))
    return files

@app.get("/api/health")
async def health():
    return {"careerlink":"ok", "litellm":await check_litellm()}

@app.get("/api/models")
async def models():
    try:
        ms=await list_models()
        return {"models":ms}
    except Exception as e:
        return {"models":[],"error":str(e)}

@app.get("/api/project")
async def default_project(): return DEFAULT_PROJECT
@app.get("/api/projects")
async def projects(): return list_projects()
@app.post("/api/projects")
async def new_project(payload:dict):
    name=(payload.get("name") or "").strip()
    if not name: raise HTTPException(400,"Project name required")
    return create_project(name=name,description=payload.get("description") or "",agents=[])

@app.delete("/api/projects/{project_id}")
async def remove_project(project_id:str):
    if not delete_project(project_id): raise HTTPException(400,"Cannot delete project")
    return {"ok":True}

@app.get("/api/chats")
async def chats(project_id:str|None=None): return list_chats(project_id)
@app.get("/api/chats/{chat_id}")
async def chat_get(chat_id:str):
    c=get_chat(chat_id)
    if not c: raise HTTPException(404,"Chat not found")
    return c
@app.post("/api/chats")
async def chat_save(payload:dict):
    return save_chat(payload.get("id"),payload.get("project_id") or DEFAULT_PROJECT["id"],
                     payload.get("title") or "Chat",payload.get("history") or [],payload.get("messages_html") or "")
@app.delete("/api/chats/{chat_id}")
async def chat_remove(chat_id:str):
    if not delete_chat(chat_id): raise HTTPException(404,"Chat not found")
    return {"ok":True}

@app.post("/api/chat",response_model=ChatResponse)
async def chat(req:ChatRequest):
    try:
        result=await call_model(req.model,req.message,req.history)
    except LLMError as e:
        raise HTTPException(502,str(e))
    files=[]
    code_files=extract_code_files(result["content"])
    if code_files:
        if len(code_files)>1: files.append(make_zip(code_files,"careerlink_code.zip"))
        for name,content in code_files: files.append(write_output_file(name,content))
    return ChatResponse(reply=result,files=files)

@app.post("/api/files/upload")
async def upload_file(file:UploadFile=File(...)):
    content=await file.read()
    if len(content)>20*1024*1024: raise HTTPException(400,"File too large (max 20 MB)")
    meta=save_upload(file.filename or "upload.bin",content)
    return {**meta,"preview":content.decode("utf-8",errors="replace")[:2000]}

@app.get("/api/files/download/{stored_name}")
async def download_file(stored_name:str):
    if ".." in stored_name or "/" in stored_name or "\\" in stored_name: raise HTTPException(400,"Invalid filename")
    p=OUTPUTS_DIR/stored_name
    if not p.exists(): p=UPLOADS_DIR/stored_name
    if not p.exists(): raise HTTPException(404,"File not found")
    return FileResponse(p,filename=p.name.split("_",2)[-1] if "_" in p.name else p.name,media_type="application/octet-stream")
@app.get("/api/files/outputs")
async def outputs(): return list_outputs()
@app.delete("/api/files/{stored_name}")
async def output_delete(stored_name:str):
    if not delete_output(stored_name): raise HTTPException(404,"File not found")
    return {"ok":True}

FRONTEND_DIR=Path(__file__).resolve().parent.parent/"frontend"
app.mount("/",StaticFiles(directory=str(FRONTEND_DIR),html=True),name="frontend")

if __name__=="__main__":
    import uvicorn
    uvicorn.run("main:app",host="0.0.0.0",port=8000,reload=True)
