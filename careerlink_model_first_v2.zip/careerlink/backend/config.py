"""
Careerlink AI configuration.
Careerlink is currently model-first: one selected LiteLLM model handles each chat.
Teams/roles are intentionally disabled in this UI and can be added later.
"""
from pathlib import Path

LITELLM_BASE_URL = "http://localhost:4000"
LITELLM_TIMEOUT = 120.0

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
PROJECTS_DIR = DATA_DIR / "projects"
UPLOADS_DIR = DATA_DIR / "uploads"
OUTPUTS_DIR = DATA_DIR / "outputs"

for d in (PROJECTS_DIR, UPLOADS_DIR, OUTPUTS_DIR):
    d.mkdir(parents=True, exist_ok=True)

DEFAULT_PROJECT = {
    "id": "careerlink-platform",
    "name": "Careerlink Platform",
    "description": "The Careerlink system itself.",
    "status": "active",
}

SYSTEM_PROMPT = """You are Careerlink AI, a practical general-purpose assistant.
Answer the user's request directly. Do not pretend to be a team or mention hidden
agents, roles, routing, fallback teams, or demo mode. If you write code, make it
complete and usable. Be honest about what you can verify."""
