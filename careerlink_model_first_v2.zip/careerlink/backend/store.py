"""
Simple JSON store for projects and chats (server-side persistence).
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from config import DATA_DIR, DEFAULT_PROJECT

STORE_DIR = DATA_DIR / "store"
PROJECTS_FILE = STORE_DIR / "projects.json"
CHATS_FILE = STORE_DIR / "chats.json"

STORE_DIR.mkdir(parents=True, exist_ok=True)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _read(path: Path, default: Any):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _write(path: Path, data: Any) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


# ---------- Projects ----------

def list_projects() -> list[dict]:
    projects = _read(PROJECTS_FILE, None)
    if not projects:
        # seed default
        projects = [dict(DEFAULT_PROJECT)]
        _write(PROJECTS_FILE, projects)
    return projects


def get_project(project_id: str) -> dict | None:
    for p in list_projects():
        if p["id"] == project_id:
            return p
    return None


def create_project(name: str, description: str = "", agents: list[str] | None = None) -> dict:
    projects = list_projects()
    p = {
        "id": "proj-" + uuid.uuid4().hex[:10],
        "name": name.strip() or "Untitled project",
        "description": (description or "").strip(),
        "agents": agents or ["manager", "researcher", "coder", "debugger", "reviewer", "vision"],
        "status": "active",
        "created_at": _now(),
    }
    projects.append(p)
    _write(PROJECTS_FILE, projects)
    return p


def delete_project(project_id: str) -> bool:
    if project_id == DEFAULT_PROJECT["id"]:
        return False  # protect default
    projects = list_projects()
    new_list = [p for p in projects if p["id"] != project_id]
    if len(new_list) == len(projects):
        return False
    _write(PROJECTS_FILE, new_list)
    # also delete chats belonging to this project
    chats = list_chats()
    _write(CHATS_FILE, [c for c in chats if c.get("project_id") != project_id])
    return True


# ---------- Chats ----------

WELCOME_MARKER = "Welcome to **Careerlink AI.**"

def _clean_history(history):
    return [m for m in (history or []) if WELCOME_MARKER not in (m.get("content") or "")]

def list_chats(project_id: str | None = None) -> list[dict]:
    chats = _read(CHATS_FILE, [])
    for c in chats:
        c["history"] = _clean_history(c.get("history"))
        # Never return the old built-in welcome HTML.
        if WELCOME_MARKER in (c.get("messages_html") or ""):
            c["messages_html"] = ""

    if project_id:
        chats = [c for c in chats if c.get("project_id") == project_id]
    # newest first
    return sorted(chats, key=lambda c: c.get("updated_at") or c.get("created_at") or "", reverse=True)


def get_chat(chat_id: str) -> dict | None:
    for c in _read(CHATS_FILE, []):
        if c["id"] == chat_id:
            c["history"] = _clean_history(c.get("history"))
            if WELCOME_MARKER in (c.get("messages_html") or ""):
                c["messages_html"] = ""
            return c
    return None


def save_chat(
    chat_id: str | None,
    project_id: str,
    title: str,
    history: list[dict],
    messages_html: str = "",
) -> dict:
    chats = _read(CHATS_FILE, [])
    now = _now()
    if chat_id:
        for c in chats:
            if c["id"] == chat_id:
                c["title"] = title[:80] or c.get("title") or "Chat"
                c["history"] = _clean_history(history)
                c["messages_html"] = messages_html
                c["updated_at"] = now
                c["project_id"] = project_id
                _write(CHATS_FILE, chats)
                return c

    # create new
    new_chat = {
        "id": "chat-" + uuid.uuid4().hex[:10],
        "project_id": project_id,
        "title": (title or "New chat")[:80],
        "history": history,
        "messages_html": messages_html,
        "created_at": now,
        "updated_at": now,
    }
    chats.insert(0, new_chat)
    # keep last 100
    chats = chats[:100]
    _write(CHATS_FILE, chats)
    return new_chat


def delete_chat(chat_id: str) -> bool:
    chats = _read(CHATS_FILE, [])
    new_list = [c for c in chats if c["id"] != chat_id]
    if len(new_list) == len(chats):
        return False
    _write(CHATS_FILE, new_list)
    return True


# ---------- Teams ----------

TEAMS_FILE = STORE_DIR / "teams.json"

# Default built-in team mirrors MODEL_FALLBACKS structure (primary model only as selection)
DEFAULT_TEAM = {
    "id": "team-default",
    "name": "Default Team",
    "description": "Standard Careerlink team with configured fallbacks",
    "jobs": {
        "manager": {"enabled": True, "models": ["nvidia-nemotron", "groq-llama", "cerebras"]},
        "researcher": {"enabled": True, "models": ["groq-llama", "nvidia-nemotron", "openrouter-free"]},
        "coder": {"enabled": True, "models": ["cerebras", "groq-llama", "nvidia-nemotron"]},
        "debugger": {"enabled": True, "models": ["nvidia-nemotron", "groq-llama", "cerebras"]},
        "reviewer": {"enabled": True, "models": ["groq-llama", "nvidia-nemotron", "openrouter-free"]},
        "vision": {"enabled": True, "models": ["openrouter-free", "groq-llama"]},
    },
    "created_at": "2026-01-01T00:00:00+00:00",
}


def list_teams() -> list[dict]:
    teams = _read(TEAMS_FILE, None)
    if not teams:
        teams = [dict(DEFAULT_TEAM)]
        _write(TEAMS_FILE, teams)
    return teams


def get_team(team_id: str) -> dict | None:
    for t in list_teams():
        if t["id"] == team_id:
            return t
    return None


def create_team(name: str, description: str = "", jobs: dict | None = None) -> dict:
    teams = list_teams()
    t = {
        "id": "team-" + uuid.uuid4().hex[:10],
        "name": (name or "Untitled team").strip(),
        "description": (description or "").strip(),
        "jobs": jobs or dict(DEFAULT_TEAM["jobs"]),
        "created_at": _now(),
    }
    teams.append(t)
    _write(TEAMS_FILE, teams)
    return t


def update_team(team_id: str, name: str | None = None, description: str | None = None, jobs: dict | None = None) -> dict | None:
    teams = list_teams()
    for t in teams:
        if t["id"] == team_id:
            if name is not None:
                t["name"] = name.strip() or t["name"]
            if description is not None:
                t["description"] = description.strip()
            if jobs is not None:
                t["jobs"] = jobs
            t["updated_at"] = _now()
            _write(TEAMS_FILE, teams)
            return t
    return None


def delete_team(team_id: str) -> bool:
    if team_id == DEFAULT_TEAM["id"]:
        return False
    teams = list_teams()
    new_list = [t for t in teams if t["id"] != team_id]
    if len(new_list) == len(teams):
        return False
    _write(TEAMS_FILE, new_list)
    return True
